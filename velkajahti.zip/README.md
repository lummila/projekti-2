# projekti-2
Velkajahti


velkajahti.sql on MySQL(MariaDB)-tietokannan lähdetiedosto, asenna se koneellesi ennen pelaamista.

Lisäksi avaa sql.py-tiedosto ja muokkaa Sql-luokan konstruktoriin oikeat tiedot tietokantayhteyden avaamiseksi.

App.py on pelin taustapalvelu.